# Digital World Offline — Mobile Lab (v0.3)

Protótipo **original** de RPG 3D offline para Android inspirado em sistemas gerais de jogos de monstros parceiros. **Não é uma versão oficial nem um port do Digimon Masters Online.** O repositório não inclui arquivos proprietários, personagens ou recursos do DMO.

## O que já foi implementado

- Cena 3D procedural colorida: praça, casas, árvores, campo, monumento e inimigos.
- Personagem controlável via joystick virtual multitoque ou WASD/setas.
- Câmera isométrica/terceira pessoa seguindo o jogador.
- Parceiro acompanhando, 8 inimigos com perseguição, HP, dano, respawn.
- Botões de atacar, digievoluir no nível 3, reverter e consumir poções.
- EXP, níveis de treinador e parceiro, bits, missão inicial e recompensas.
- Salvamento automático **offline**, em `user://digital_world_save_v1.json` (15s, pausa e encerramento).
- Carregamento opcional de modelos `.glb` obtidos e convertidos legitimamente **somente na máquina do usuário**.
- Preparação para compilação debug Android (Godot 4.4.1).

## Teste no computador

1. Abra esta pasta no [Godot Engine 4.4.1](https://godotengine.org/download/archive/4.4.1-stable/).
2. Execute `scenes/main.tscn` com F6 ou o projeto com F5.
3. Movimente com WASD, `J` para atacar, `E` para evoluir, `H` para poção.

## Build APK debug

### Pelo GitHub Actions

No GitHub, selecione **Actions → Build Android APK (debug)** e execute o fluxo (ou use o artefato produzido pelo push). Ao terminar **com sucesso**, baixe o artefato `digital-world-offline-android-debug`; dentro dele haverá o APK. **Não distribua o APK com recursos originais do DMO.**

### Pelo Godot local

Consulte [Exporting for Android](https://docs.godotengine.org/en/4.4/tutorials/export/exporting_for_android.html) para instalar Android SDK, JDK 17 e export templates. Abra **Projeto → Exportar → Android → Exportar Projeto (debug)**.

## Recursos locais originais

Caso você disponha de modelos 3D com autorização para uso, converta-os para `.glb` no Blender, coloque na pasta `assets/user_models/` e importe no Godot. Consulte `assets/user_models/README.md`. Esses arquivos são ignorados pelo Git e não devem ser enviados para um repositório público sem direito de distribuição.

## Limitações conhecidas

- Protótipo inicial: não contém mapas, Digimons, modelos ou protocolo do DMO original.
- Não há multiplayer, servidor, banco de dados ou autenticação.
- Sem sistema de navegação para inimigos (movem-se em linha reta), sem animações esqueléticas e sem colisão detalhada com decorações.
- A missão inicial é uma demonstração; seu progresso permanece salvo após completá-la.
- Renderizador OpenGL Compatibility escolhido para maior alcance Android; desempenho varia conforme o aparelho.
- A compilação APK só fica disponível **se** o pipeline do GitHub Actions terminar sem erros. Ainda não foi validada em aparelho físico.

## Privacidade

Jogo inteiramente offline, sem permissão INTERNET. Todos os dados do jogador permanecem no armazenamento privativo do app Android. Desinstalar o aplicativo pode apagar os saves.
