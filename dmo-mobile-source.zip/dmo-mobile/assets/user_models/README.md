# Modelos locais (NÃO subir ao GitHub)

Coloque aqui SOMENTE modelos que você tenha permissão para usar, já convertidos para glTF binário `.glb`.
Nomes opcionais suportados pelo protótipo:

- `trainer.glb`: substitui o personagem principal
- `partner.glb`: substitui o parceiro na forma inicial
- `partner_evolved.glb`: substitui o parceiro evoluído
- `enemy.glb`: substitui o monstro hostil

Ajuste escala e orientação no Blender antes de exportar (frente voltada para -Z, origem no solo).
Arquivos `.nif`, `.pf` e `.hf` NÃO são carregados automaticamente pelo Godot.
Este projeto não contém material original do DMO nem ferramentas para contornar proteções.
