extends Node3D
## Digital World Offline: a small original, offline 3D Android RPG prototype.
## No server, third-party assets, account service, tracking, or network requests.

const Joystick = preload("res://scripts/joystick.gd")
const SAVE_FILE: String = "user://digital_world_save_v1.json"
const PLAYER_SPEED: float = 7.0
const FIELD_LIMIT: float = 37.0
const ENEMY_LOCATIONS: Array[Vector3] = [
	Vector3(-11, 0, -12), Vector3(-21, 0, -22), Vector3(8, 0, -17),
	Vector3(21, 0, -23), Vector3(-27, 0, 5), Vector3(24, 0, 8),
	Vector3(0, 0, -30), Vector3(-14, 0, -33)
]

var player: CharacterBody3D
var player_visual: Node3D
var partner: Node3D
var partner_visual: Node3D
var camera: Camera3D
var joy
var hp_bar: ProgressBar
var exp_bar: ProgressBar
var status_label: Label
var quest_label: Label
var message_label: Label
var evolve_button: Button
var heal_button: Button
var attack_button: Button
var enemies: Array[Dictionary] = []
var level: int = 1
var experience: int = 0
var partner_level: int = 1
var partner_exp: int = 0
var evolved: bool = false
var player_hp: int = 100
var potions: int = 3
var coins: int = 0
var quest_defeated: int = 0
var attack_cooldown: float = 0.0
var player_hit_cooldown: float = 0.0
var run_time: float = 0.0
var feedback_time: float = 0.0
var game_ready: bool = false
var mats: Dictionary = {}

func _ready() -> void:
	_build_environment()
	_build_field()
	_spawn_player()
	_spawn_partner()
	_spawn_enemies()
	_build_ui()
	_load_game()
	_refresh_hud()
	var autosave := Timer.new()
	autosave.wait_time = 15.0
	autosave.autostart = true
	autosave.timeout.connect(_save_game)
	add_child(autosave)
	game_ready = true
	_say("Bem-vindo ao Campo Digital! Derrote 5 Corrompidos.", 6.0)

func _physics_process(delta: float) -> void:
	if not game_ready:
		return
	run_time += delta
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	player_hit_cooldown = maxf(0.0, player_hit_cooldown - delta)
	feedback_time = maxf(0.0, feedback_time - delta)
	if feedback_time <= 0.0:
		message_label.text = ""

	var keyboard := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction: Vector2 = joy.direction if joy.direction.length() > 0.08 else keyboard
	var world_dir := Vector3(direction.x, 0.0, direction.y)
	if world_dir.length() > 1.0:
		world_dir = world_dir.normalized()
	player.velocity.x = world_dir.x * PLAYER_SPEED
	player.velocity.z = world_dir.z * PLAYER_SPEED
	if not player.is_on_floor():
		player.velocity.y -= 19.6 * delta
	else:
		player.velocity.y = -0.2
	player.move_and_slide()
	player.position.x = clampf(player.position.x, -FIELD_LIMIT, FIELD_LIMIT)
	player.position.z = clampf(player.position.z, -FIELD_LIMIT, FIELD_LIMIT)
	if world_dir.length() > 0.05:
		player_visual.rotation.y = lerp_angle(player_visual.rotation.y, atan2(-world_dir.x, -world_dir.z), minf(1.0, delta * 10.0))
		player_visual.position.y = sin(run_time * 13.0) * 0.05
	else:
		player_visual.position.y = lerpf(player_visual.position.y, 0.0, minf(1.0, delta * 8.0))

	var follow_offset := Vector3(1.6, 0.0, 1.35)
	var follow_pos: Vector3 = player.global_position + follow_offset
	partner.global_position = partner.global_position.lerp(follow_pos, minf(1.0, delta * 5.0))
	partner.position.y = 0.13 + sin(run_time * 5.2) * 0.13
	partner_visual.rotation.y = lerp_angle(partner_visual.rotation.y, player_visual.rotation.y, minf(1.0, delta * 5.0))

	var cam_target: Vector3 = player.global_position + Vector3(0, 11.0, 16.0)
	camera.global_position = camera.global_position.lerp(cam_target, minf(1.0, delta * 3.5))
	camera.look_at(player.global_position + Vector3(0, 1.8, -2.0), Vector3.UP)
	_update_enemies(delta)
	attack_button.disabled = attack_cooldown > 0.01

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("attack"):
		_attack()
	elif event.is_action_pressed("evolve"):
		_toggle_evolution()
	elif event.is_action_pressed("heal"):
		_heal()

func _notification(what: int) -> void:
	if game_ready and (what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED):
		_save_game()

func _exit_tree() -> void:
	if game_ready:
		_save_game()

func _material(name: String, color: Color, emission: bool = false) -> StandardMaterial3D:
	if mats.has(name):
		return mats[name] as StandardMaterial3D
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.86
	if emission:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 1.6
	mats[name] = m
	return m

func _box(parent: Node3D, size3: Vector3, pos: Vector3, material: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size3
	node.mesh = mesh
	node.material_override = material
	node.position = pos
	node.rotation_degrees = rot
	parent.add_child(node)
	return node

func _sphere(parent: Node3D, radius: float, pos: Vector3, material: Material, size3: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 12
	mesh.rings = 6
	node.mesh = mesh
	node.material_override = material
	node.position = pos
	node.scale = size3
	parent.add_child(node)
	return node

func _cylinder(parent: Node3D, height3: float, bottom: float, top: float, pos: Vector3, material: Material) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.height = height3
	mesh.bottom_radius = bottom
	mesh.top_radius = top
	mesh.radial_segments = 8
	node.mesh = mesh
	node.material_override = material
	node.position = pos
	parent.add_child(node)
	return node

func _build_environment() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("7bbbdc")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("d3e7ff")
	env.ambient_light_energy = 0.78
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env_node.environment = env
	add_child(env_node)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-54, -28, 0)
	sun.light_color = Color("ffebc4")
	sun.light_energy = 1.05
	sun.shadow_enabled = false # GPU-friendly Android baseline
	add_child(sun)

	camera = Camera3D.new()
	camera.current = true
	camera.fov = 61.0
	camera.near = 0.15
	camera.far = 180.0
	add_child(camera)

func _build_field() -> void:
	var grass := _material("grass", Color("6caf83"))
	var grass2 := _material("grass_patch", Color("80c28d"))
	var stone := _material("stone", Color("a8bab2"))
	var sand := _material("sand", Color("d9c79d"))
	var wood := _material("wood", Color("8f634b"))
	var leaf := _material("leaf", Color("3d8768"))
	var leaf_light := _material("leaf_light", Color("4f9f79"))
	var roof := _material("roof", Color("3a6f83"))
	var teal := _material("teal", Color("6ce1c6"), true)
	var violet := _material("violet", Color("8b79c7"), true)
	var pale := _material("pale", Color("f8e7c4"))

	_box(self, Vector3(85, 0.55, 85), Vector3(0, -0.34, 0), grass)
	var floor_body := StaticBody3D.new()
	var ground_collision := CollisionShape3D.new()
	var ground_shape := BoxShape3D.new()
	ground_shape.size = Vector3(85, 0.55, 85)
	ground_collision.shape = ground_shape
	floor_body.position = Vector3(0, -0.34, 0)
	floor_body.add_child(ground_collision)
	add_child(floor_body)

	# Warm plaza, road to monster field and lateral paths.
	_box(self, Vector3(14, 0.045, 12), Vector3(0, 0.01, 13), sand)
	_box(self, Vector3(5.0, 0.05, 29), Vector3(0, 0.01, -8), stone)
	for i in range(-3, 4):
		_box(self, Vector3(1.8, 0.065, 1.35), Vector3(i * 2.0, 0.018, 6), sand)
	for j in range(50):
		var rng := RandomNumberGenerator.new()
		rng.seed = j * 1597 + 725
		var p := Vector3(rng.randf_range(-38.0, 38.0), 0.01, rng.randf_range(-37.0, 37.0))
		if p.length() < 13.0 or absf(p.x) < 4.0:
			continue
		if j % 3 == 0:
			_tree(p, wood, leaf if j % 2 == 0 else leaf_light)
		else:
			_sphere(self, 0.45, p + Vector3(0, 0.25, 0), grass2, Vector3(1.5, 0.5, 1.1))

	# Decorative houses in the non-combat hub.
	_house(Vector3(-13, 0, 15), wood, roof, pale)
	_house(Vector3(13, 0, 13), wood, roof, pale)
	# Portal monument at the edge of the field.
	_cylinder(self, 0.45, 3.1, 3.1, Vector3(0, 0.24, -37), stone)
	for i in range(6):
		var angle := float(i) * TAU / 6.0
		var px: float = sin(angle) * 2.5
		var pz: float = -37.0 + cos(angle) * 2.5
		_cylinder(self, 2.0, 0.4, 0.28, Vector3(px, 1.23, pz), violet)
	_sphere(self, 1.2, Vector3(0, 2.7, -37), teal)
	# Landmark crystals.
	for p in [Vector3(-31, 0, -28), Vector3(28, 0, -27), Vector3(-30, 0, 28)]:
		_cylinder(self, 2.0, 0.45, 0.01, p + Vector3(0, 1, 0), violet)

	var sign := Label3D.new()
	sign.text = "PRAÇA DIGITAL"
	sign.font_size = 55
	sign.pixel_size = 0.007
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sign.modulate = Color("153c4c")
	sign.position = Vector3(0, 3.2, 19.1)
	add_child(sign)

func _tree(pos: Vector3, trunk: Material, foliage: Material) -> void:
	var n := Node3D.new()
	n.position = pos
	add_child(n)
	_cylinder(n, 2.8, 0.35, 0.25, Vector3(0, 1.4, 0), trunk)
	_sphere(n, 1.55, Vector3(0, 3.1, 0), foliage, Vector3(1, 1.05, 1))
	_sphere(n, 0.95, Vector3(-0.75, 2.65, 0), foliage)
	_sphere(n, 1.05, Vector3(0.7, 2.7, 0.2), foliage)

func _house(pos: Vector3, wood: Material, roof: Material, pale: Material) -> void:
	var h := Node3D.new()
	h.position = pos
	add_child(h)
	_box(h, Vector3(7, 4.5, 6), Vector3(0, 2.27, 0), wood)
	_box(h, Vector3(4.4, 0.14, 0.15), Vector3(0, 2.65, 3.05), pale)
	_box(h, Vector3(1.45, 2.6, 0.12), Vector3(0, 1.34, 3.08), _material("door", Color("31586c")))
	_box(h, Vector3(1.5, 1.4, 0.13), Vector3(-2.27, 2.55, 3.08), _material("window", Color("a4e2e3"), true))
	_box(h, Vector3(1.5, 1.4, 0.13), Vector3(2.27, 2.55, 3.08), _material("window", Color("a4e2e3"), true))
	_box(h, Vector3(4.65, 0.48, 7.2), Vector3(-1.55, 5.25, 0), roof, Vector3(0, 0, 25))
	_box(h, Vector3(4.65, 0.48, 7.2), Vector3(1.55, 5.25, 0), roof, Vector3(0, 0, -25))

func _try_import_model(path: String) -> Node3D:
	if not ResourceLoader.exists(path):
		return null
	var resource := load(path)
	if resource is PackedScene:
		var instance := (resource as PackedScene).instantiate()
		if instance is Node3D:
			return instance as Node3D
	return null

func _spawn_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Treinador"
	player.position = Vector3(0, 0.08, 15)
	var collider := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.height = 1.9
	shape.radius = 0.39
	collider.shape = shape
	collider.position.y = 0.95
	player.add_child(collider)
	add_child(player)
	player_visual = Node3D.new()
	player.add_child(player_visual)
	var custom := _try_import_model("res://assets/user_models/trainer.glb")
	if custom != null:
		player_visual.add_child(custom)
	else:
		_human_appearance(player_visual)

func _human_appearance(p: Node3D) -> void:
	var uniform := _material("uniform", Color("253e65"))
	var skin := _material("skin", Color("e5b18c"))
	var hair := _material("hair", Color("263347"))
	var cyan := _material("cyan", Color("56ddcd"), true)
	_box(p, Vector3(0.85, 1.05, 0.45), Vector3(0, 1.4, 0), uniform)
	_sphere(p, 0.36, Vector3(0, 2.3, 0), skin)
	_sphere(p, 0.38, Vector3(0, 2.50, 0.08), hair, Vector3(1.0, 0.4, 0.94))
	_box(p, Vector3(0.29, 1.00, 0.32), Vector3(-0.23, 0.5, 0), hair)
	_box(p, Vector3(0.29, 1.00, 0.32), Vector3(0.23, 0.5, 0), hair)
	_box(p, Vector3(0.27, 0.91, 0.34), Vector3(-0.58, 1.49, 0), skin, Vector3(0, 0, -9))
	_box(p, Vector3(0.27, 0.91, 0.34), Vector3(0.58, 1.49, 0), skin, Vector3(0, 0, 9))
	_box(p, Vector3(0.50, 0.16, 0.52), Vector3(0, 1.62, -0.26), cyan)

func _spawn_partner() -> void:
	partner = Node3D.new()
	partner.position = player.position + Vector3(1.6, 0.1, 1.35)
	partner.name = "Parceiro"
	add_child(partner)
	partner_visual = Node3D.new()
	partner.add_child(partner_visual)
	_refresh_partner_visual()

func _refresh_partner_visual() -> void:
	for child in partner_visual.get_children():
		child.queue_free()
	var path: String = "res://assets/user_models/partner_evolved.glb" if evolved else "res://assets/user_models/partner.glb"
	var original := _try_import_model(path)
	if original != null:
		partner_visual.add_child(original)
	else:
		_partner_appearance(partner_visual, evolved)

func _partner_appearance(parent: Node3D, strong: bool) -> void:
	var blue := _material("partner_blue", Color("36b0bc"))
	var dark := _material("partner_dark", Color("24637c"))
	var light := _material("partner_light", Color("8aefdf"))
	var eye := _material("eyes", Color("fffaf1"), true)
	var glow := _material("eyes_dark", Color("162c39"))
	var factor: float = 1.45 if strong else 1.0
	var model := Node3D.new()
	model.scale = Vector3.ONE * factor
	parent.add_child(model)
	_sphere(model, 0.60, Vector3(0, 0.78, 0), blue, Vector3(1, 1.08, 0.86))
	_sphere(model, 0.49, Vector3(0, 1.34, -0.28), blue, Vector3(1, 0.88, 1))
	_sphere(model, 0.25, Vector3(-0.26, 1.43, -0.68), eye)
	_sphere(model, 0.25, Vector3(0.26, 1.43, -0.68), eye)
	_sphere(model, 0.08, Vector3(-0.27, 1.42, -0.885), glow)
	_sphere(model, 0.08, Vector3(0.27, 1.42, -0.885), glow)
	_sphere(model, 0.36, Vector3(0, 0.69, -0.44), light, Vector3(1.0, 1.0, 0.3))
	_sphere(model, 0.25, Vector3(-0.53, 0.26, -0.25), dark)
	_sphere(model, 0.25, Vector3(0.53, 0.26, -0.25), dark)
	_sphere(model, 0.18, Vector3(-0.70, 0.98, 0.04), dark)
	_sphere(model, 0.18, Vector3(0.70, 0.98, 0.04), dark)
	var tail := _cylinder(model, 0.95, 0.21, 0.04, Vector3(0, 0.58, 0.81), blue)
	tail.rotation_degrees.x = 65
	if strong:
		for x in [-0.38, 0.38]:
			var horn := _cylinder(model, 0.65, 0.16, 0.01, Vector3(x, 1.89, -0.2), light)
			horn.rotation_degrees.z = 16 if x < 0 else -16
		_box(model, Vector3(1.4, 0.16, 0.24), Vector3(0, 0.95, 0.55), dark)

func _spawn_enemies() -> void:
	for i in ENEMY_LOCATIONS.size():
		var pos: Vector3 = ENEMY_LOCATIONS[i]
		var node := Node3D.new()
		node.position = pos
		node.name = "Corrompido_%d" % i
		add_child(node)
		var original := _try_import_model("res://assets/user_models/enemy.glb")
		if original != null:
			node.add_child(original)
		else:
			_enemy_appearance(node)
		var label3d := Label3D.new()
		label3d.text = "Corrompido  Lv. 2"
		label3d.position = Vector3(0, 2.7, 0)
		label3d.font_size = 32
		label3d.pixel_size = 0.005
		label3d.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label3d.modulate = Color("ffd0ec")
		node.add_child(label3d)
		enemies.append({"node": node, "spawn": pos, "hp": 42, "alive": true, "respawn": 0.0, "hit_cooldown": 0.0, "label": label3d})

func _enemy_appearance(n: Node3D) -> void:
	var purple := _material("enemy", Color("755291"))
	var horn := _material("horn", Color("ce9bde"))
	var glow := _material("enemy_eye", Color("ff8ba8"), true)
	_sphere(n, 0.75, Vector3(0, 0.85, 0), purple)
	_sphere(n, 0.45, Vector3(0, 1.56, -0.1), purple)
	for x in [-0.39, 0.39]:
		_sphere(n, 0.16, Vector3(x, 1.62, -0.48), glow)
		var spike := _cylinder(n, 0.65, 0.22, 0.01, Vector3(x * 1.3, 2.13, -0.06), horn)
		spike.rotation_degrees.z = -25.0 if x > 0.0 else 25.0
	_sphere(n, 0.29, Vector3(-0.65, 0.7, 0.02), purple)
	_sphere(n, 0.29, Vector3(0.65, 0.7, 0.02), purple)

func _update_enemies(delta: float) -> void:
	for enemy in enemies:
		var n: Node3D = enemy["node"]
		if not enemy["alive"]:
			enemy["respawn"] = float(enemy["respawn"]) - delta
			if float(enemy["respawn"]) <= 0.0:
				enemy["alive"] = true
				enemy["hp"] = 42
				n.visible = true
				n.position = enemy["spawn"]
			continue
		enemy["hit_cooldown"] = maxf(0.0, float(enemy["hit_cooldown"]) - delta)
		var to_player: Vector3 = player.global_position - n.global_position
		to_player.y = 0.0
		var distance: float = to_player.length()
		if distance < 8.0 and distance > 1.65:
			n.position += to_player.normalized() * delta * 1.35
		elif distance <= 1.65 and float(enemy["hit_cooldown"]) <= 0.0 and player_hit_cooldown <= 0.0:
			enemy["hit_cooldown"] = 1.3
			player_hit_cooldown = 0.6
			player_hp = maxi(0, player_hp - 6)
			if player_hp == 0:
				player_hp = 100
				player.global_position = Vector3(0, 0.08, 15)
				_say("Você retornou à praça para se recuperar.")
			else:
				_say("Você recebeu 6 de dano!", 1.2)
			_refresh_hud()
		n.position.y = sin(run_time * 3.3 + distance) * 0.065

func _attack() -> void:
	if attack_cooldown > 0.01 or not game_ready:
		return
	attack_cooldown = 0.72
	var target: Dictionary = {}
	var nearest: float = 5.3
	for enemy in enemies:
		if not enemy["alive"]:
			continue
		var n: Node3D = enemy["node"]
		var distance: float = player.global_position.distance_to(n.global_position)
		if distance < nearest:
			nearest = distance
			target = enemy
	if target.is_empty():
		_say("Aproxime-se de um Corrompido para atacar.", 1.6)
		return
	var target_node: Node3D = target["node"]
	var damage: int = 15 + partner_level * 3 + (16 if evolved else 0)
	target["hp"] = int(target["hp"]) - damage
	_spawn_burst(target_node.global_position + Vector3(0, 1.1, 0), Color("77f3e4") if evolved else Color("ffeaa0"))
	var damage_label: Label3D = target["label"]
	damage_label.text = "-%d HP" % damage
	if int(target["hp"]) <= 0:
		target["alive"] = false
		target["respawn"] = 15.0
		target_node.visible = false
		coins += 8
		quest_defeated += 1
		_gain_experience(24)
		_say("Vitória! +24 XP  |  +8 bits", 2.1)
		if quest_defeated == 5:
			coins += 120
			potions += 2
			_say("MISSÃO CONCLUÍDA! +120 bits e +2 poções!", 5.0)
	else:
		_say("Parceiro causou %d de dano!" % damage, 1.2)
	_refresh_hud()

func _spawn_burst(where: Vector3, color: Color) -> void:
	var burst := Node3D.new()
	add_child(burst)
	burst.global_position = where
	var orb := _sphere(burst, 0.36, Vector3.ZERO, _material("burst_" + color.to_html(), color, true))
	var tw := create_tween()
	tw.tween_property(orb, "scale", Vector3.ONE * 3.6, 0.27).set_trans(Tween.TRANS_CUBIC)
	tw.tween_callback(burst.queue_free)

func _gain_experience(amount: int) -> void:
	experience += amount
	partner_exp += amount
	while experience >= _experience_needed(level):
		experience -= _experience_needed(level)
		level += 1
		player_hp = 100
	while partner_exp >= _experience_needed(partner_level):
		partner_exp -= _experience_needed(partner_level)
		partner_level += 1
	_save_game()

func _experience_needed(for_level: int) -> int:
	return 36 + (for_level - 1) * 32

func _toggle_evolution() -> void:
	if partner_level < 3:
		_say("A evolução fica disponível no nível 3 do parceiro.", 2.6)
		return
	evolved = not evolved
	_refresh_partner_visual()
	_say("Evolução ativada!" if evolved else "Parceiro voltou à forma inicial.", 2.2)
	_save_game()
	_refresh_hud()

func _heal() -> void:
	if potions <= 0:
		_say("Sem poções. Complete a missão para ganhar mais!")
		return
	if player_hp >= 100:
		_say("Sua energia já está cheia.")
		return
	potions -= 1
	player_hp = mini(100, player_hp + 45)
	_say("Poção usada: +45 HP", 2.0)
	_save_game()
	_refresh_hud()

func _save_game() -> void:
	if player == null:
		return
	var state: Dictionary = {
		"version": 1,
		"level": level,
		"xp": experience,
		"partner_level": partner_level,
		"partner_xp": partner_exp,
		"evolved": evolved,
		"hp": player_hp,
		"potions": potions,
		"coins": coins,
		"defeated": quest_defeated,
		"position": [player.position.x, player.position.y, player.position.z]
	}
	var save := FileAccess.open(SAVE_FILE, FileAccess.WRITE)
	if save != null:
		save.store_string(JSON.stringify(state, "\t"))
		save.close()

func _load_game() -> void:
	if not FileAccess.file_exists(SAVE_FILE):
		return
	var file := FileAccess.open(SAVE_FILE, FileAccess.READ)
	if file == null:
		return
	var data: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if not data is Dictionary or int(data.get("version", 0)) != 1:
		return
	level = clampi(int(data.get("level", 1)), 1, 200)
	experience = maxi(0, int(data.get("xp", 0)))
	partner_level = clampi(int(data.get("partner_level", 1)), 1, 200)
	partner_exp = maxi(0, int(data.get("partner_xp", 0)))
	evolved = bool(data.get("evolved", false)) and partner_level >= 3
	player_hp = clampi(int(data.get("hp", 100)), 1, 100)
	potions = clampi(int(data.get("potions", 3)), 0, 999)
	coins = maxi(0, int(data.get("coins", 0)))
	quest_defeated = maxi(0, int(data.get("defeated", 0)))
	var loc: Variant = data.get("position", [])
	if loc is Array and loc.size() == 3:
		player.position = Vector3(clampf(float(loc[0]), -FIELD_LIMIT, FIELD_LIMIT), 0.08, clampf(float(loc[2]), -FIELD_LIMIT, FIELD_LIMIT))
	_refresh_partner_visual()

func _panel_style(bg: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = Color("9ad8d0")
	style.set_border_width_all(2)
	style.set_corner_radius_all(14)
	style.content_margin_left = 13.0
	style.content_margin_right = 13.0
	style.content_margin_top = 10.0
	style.content_margin_bottom = 10.0
	return style

func _label(parent: Control, text_value: String, size_px: int, color: Color = Color.WHITE) -> Label:
	var label := Label.new()
	label.text = text_value
	label.add_theme_font_size_override("font_size", size_px)
	label.add_theme_color_override("font_color", color)
	parent.add_child(label)
	return label

func _progress(parent: Control, tint: Color) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(310, 23)
	bar.show_percentage = false
	var fill := StyleBoxFlat.new()
	fill.bg_color = tint
	fill.set_corner_radius_all(7)
	var background := StyleBoxFlat.new()
	background.bg_color = Color("162b39")
	background.set_corner_radius_all(7)
	bar.add_theme_stylebox_override("fill", fill)
	bar.add_theme_stylebox_override("background", background)
	parent.add_child(bar)
	return bar

func _button(root: Control, title: String, left: float, top: float, right: float, bottom: float, color: Color) -> Button:
	var b := Button.new()
	b.text = title
	b.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	b.offset_left = left
	b.offset_top = top
	b.offset_right = right
	b.offset_bottom = bottom
	b.add_theme_font_size_override("font_size", 21)
	var normal := _panel_style(color)
	var pressed := _panel_style(color.lightened(0.15))
	var disabled := _panel_style(Color("485461"))
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", pressed)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("disabled", disabled)
	b.add_theme_color_override("font_color", Color("f5fdfd"))
	b.add_theme_color_override("font_disabled_color", Color("bac6c9"))
	root.add_child(b)
	return b

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)

	var stats := PanelContainer.new()
	stats.add_theme_stylebox_override("panel", _panel_style(Color(0.055, 0.14, 0.21, 0.84)))
	stats.position = Vector2(22, 20)
	stats.custom_minimum_size = Vector2(343, 160)
	root.add_child(stats)
	var stats_box := VBoxContainer.new()
	stats_box.add_theme_constant_override("separation", 4)
	stats.add_child(stats_box)
	status_label = _label(stats_box, "TREINADOR Lv. 1", 23)
	_label(stats_box, "VIDA", 15, Color("b4d9e8"))
	hp_bar = _progress(stats_box, Color("55db93"))
	_label(stats_box, "EXPERIÊNCIA", 15, Color("b4d9e8"))
	exp_bar = _progress(stats_box, Color("65c9ff"))

	var quest_panel := PanelContainer.new()
	quest_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.055, 0.14, 0.21, 0.82)))
	quest_panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	quest_panel.offset_left = -400
	quest_panel.offset_right = -20
	quest_panel.offset_top = 20
	quest_panel.offset_bottom = 120
	root.add_child(quest_panel)
	quest_label = _label(quest_panel, "MISSÃO\nDerrote Corrompidos: 0/5", 20, Color("fff4c9"))
	quest_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART

	joy = Joystick.new()
	joy.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	joy.offset_left = 30
	joy.offset_right = 238
	joy.offset_top = -270
	joy.offset_bottom = -62
	root.add_child(joy)
	attack_button = _button(root, "ATACAR", -167, -200, -20, -73, Color("28799a"))
	attack_button.pressed.connect(_attack)
	evolve_button = _button(root, "EVOLUIR", -306, -143, -177, -63, Color("7956a6"))
	evolve_button.pressed.connect(_toggle_evolution)
	heal_button = _button(root, "POÇÃO", -166, -282, -20, -212, Color("387e69"))
	heal_button.pressed.connect(_heal)

	message_label = _label(root, "", 22, Color("fff4c9"))
	message_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	message_label.offset_left = -310
	message_label.offset_right = 310
	message_label.offset_top = -66
	message_label.offset_bottom = -25
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_color_override("font_shadow_color", Color.BLACK)
	message_label.add_theme_constant_override("shadow_offset_x", 2)
	message_label.add_theme_constant_override("shadow_offset_y", 2)

func _refresh_hud() -> void:
	if status_label == null:
		return
	status_label.text = "TREINADOR Lv.%d  |  %d bits" % [level, coins]
	hp_bar.value = player_hp
	hp_bar.max_value = 100
	exp_bar.max_value = _experience_needed(level)
	exp_bar.value = experience
	var mission: String = "CONCLUÍDA" if quest_defeated >= 5 else "%d / 5" % quest_defeated
	quest_label.text = "CAMPO DIGITAL\nMissão: Corrompidos %s\nParceiro Lv.%d  |  %s" % [mission, partner_level, "EVOLUÍDO" if evolved else "INICIAL"]
	evolve_button.text = "REVERTER" if evolved else "EVOLUIR"
	heal_button.text = "POÇÃO (%d)" % potions

func _say(message: String, duration: float = 2.5) -> void:
	if message_label != null:
		message_label.text = message
		feedback_time = duration
