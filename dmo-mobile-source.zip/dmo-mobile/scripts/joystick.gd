extends Control
## Independent multitouch joystick. A Button elsewhere never drives this control.

var direction: Vector2 = Vector2.ZERO
var active_index: int = -1
var center: Vector2 = Vector2.ZERO
const DEAD_ZONE: float = 0.13

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	center = size * 0.5
	resized.connect(func(): center = size * 0.5; queue_redraw())
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and active_index == -1:
			active_index = event.index
			_set_position(event.position)
			accept_event()
		elif not event.pressed and active_index == event.index:
			_reset()
			accept_event()
	elif event is InputEventScreenDrag and event.index == active_index:
		_set_position(event.position)
		accept_event()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed and active_index == -1:
			active_index = -2
			_set_position(event.position)
		elif not event.pressed and active_index == -2:
			_reset()
		accept_event()
	elif event is InputEventMouseMotion and active_index == -2:
		_set_position(event.position)
		accept_event()

func _set_position(pos: Vector2) -> void:
	var radius: float = minf(size.x, size.y) * 0.35
	var offset: Vector2 = (pos - center).limit_length(radius)
	direction = offset / radius
	if direction.length() < DEAD_ZONE:
		direction = Vector2.ZERO
	queue_redraw()

func _reset() -> void:
	active_index = -1
	direction = Vector2.ZERO
	queue_redraw()

func _draw() -> void:
	var radius: float = minf(size.x, size.y) * 0.37
	draw_circle(center, radius + 13.0, Color(0.07, 0.13, 0.23, 0.45))
	draw_arc(center, radius, 0.0, TAU, 64, Color(0.66, 0.94, 0.99, 0.76), 5.0, true)
	draw_circle(center + direction * radius * 0.75, radius * 0.47, Color(0.12, 0.38, 0.56, 0.92))
	draw_arc(center + direction * radius * 0.75, radius * 0.47, 0.0, TAU, 36, Color(0.78, 0.98, 1.0, 0.95), 3.0, true)
